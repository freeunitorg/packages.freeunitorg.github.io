FreeUnit WASM — Development libraries for WebAssembly modules
=============================================================

|Project Status: Active| |GitHub Discussions|

.. |Project Status: Active| image:: https://www.repostatus.org/badges/latest/active.svg
    :alt: Project Status: Active – The project has reached a stable, usable state and is being actively developed.
    :target: https://www.repostatus.org/#active

.. |GitHub Discussions| image:: https://img.shields.io/badge/GitHub-discussions-009639
    :alt: GitHub Discussions
    :target: https://github.com/freeunitorg/freeunit/discussions

**Free as in freedom.**

C library and Rust crates for building WebAssembly modules for FreeUnit.

> The original `unit-wasm` repository was archived by NGINX in October 2025.
> FreeUnit WASM is the community-maintained continuation.

Forked from the original `nginx/unit-wasm` to ensure:
- Long-term compatibility with FreeUnit
- Ongoing security maintenance
- Independent, community-driven governance

What is this?
-------------

This repository provides:

- **C library** (`libunit-wasm`) for writing WebAssembly modules in C
- **Rust crates** for writing WebAssembly modules in Rust
- **Demo examples** in both C and Rust
- **Build infrastructure** for compiling WebAssembly modules for FreeUnit

When to use this
----------------

Use this repository if you need to **write custom WebAssembly modules** for FreeUnit.

For **running** WebAssembly modules in FreeUnit, see the `main FreeUnit repository <https://github.com/freeunitorg/freeunit>`_.

Quickstart
----------

Building the C library and examples
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code-block:: console

    $ git clone https://github.com/freeunitorg/freeunit-wasm
    $ cd freeunit-wasm
    $ make WASI_SYSROOT=/path/to/wasi-sysroot all

Building the Rust crates and examples
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code-block:: console

    $ make rust
    $ make examples-rust

Using with FreeUnit
~~~~~~~~~~~~~~~~~~~

See the `Using With Unit <https://github.com/freeunitorg/freeunit-wasm#using-with-unit>`_ section in the full documentation.

Requirements
------------

- `clang` (with WebAssembly target support)
- `wasi-sysroot` (WASI SDK)
- For Rust: `rustc`, `cargo`, `wasm32-wasi` target

On Fedora:

.. code-block:: console

    # dnf install clang lld wasi-libc-devel cargo rust rust-std-static-wasm32-wasi

On Debian/Ubuntu:

.. code-block:: console

    # apt install wasi-libc make clang lld
    $ rustup target add wasm32-wasi

Changes from upstream
---------------------

- Removed "archived" and "unsupported" warnings
- Updated branding and documentation for FreeUnit
- Active maintenance for compatibility with FreeUnit

Community
---------

- `Discussions <https://github.com/freeunitorg/freeunit/discussions>`_
- `Issues <https://github.com/freeunitorg/freeunit-wasm/issues>`_
- `Website <https://freeunit.org>`_
- `team@freeunit.org <mailto:team@freeunit.org>`_

License
-------

Apache License 2.0 (same as original)

---

*Forked from `nginx/unit-wasm <https://github.com/nginx/unit-wasm>`_ — original authors retain full credit.*
